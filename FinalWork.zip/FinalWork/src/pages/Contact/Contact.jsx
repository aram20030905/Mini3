import "./contact.css"



function Contact(){


    function se(){
        alert("Մեր մասնագետը շուտով կկապվի Ձեզ հետ")
    }
    return (


      <div>
            <div className="ss">
                <div className="contact">
                       <h1>Կապ</h1>                       
                       <input type="text" placeholder="Enter your name..."/>
                       <input type="text" placeholder="Enter your surname..."/>
                       <textarea type="text" placeholder="Enter your suggest..."/>
                       <button onClick={se}>Ուղղարկել</button>
                    </div>
           <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d24379.384091880172!2d44.477989449999995!3d40.1996524!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1shy!2sam!4v1730885455118!5m2!1shy!2sam" width="600" height="450"  allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
         
            </div>
        
    )
}
export default Contact