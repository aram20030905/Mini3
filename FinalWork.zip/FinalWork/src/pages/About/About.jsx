
import "./about.css"
import image5 from "../../image/5.png"

function About(){
    return (
        <div>
            <div className="art1">
           <div className="art2">
               <img src={image5}/>
           </div>
           <div  className="art3">
           <h2>Մեր Մասին</h2>
     
           <p>Մեր Օնլայն շոփը Հայաստանում է արդեն 1 տարի։ Մենք զղաղվում ենք ապրանքների առաքմամբ ողջ Հայաստանի տարածքով։ Մենք առաքումը անվճար է նաև մարզերում։ Մեր ապրանքները շուկայական գնից ավելի մատչելի է որակով։ Վերջին մեկ տարվա ընթաքում մենք նաև մասնաճյուղեր ենք բացել աշխարհի մի շարք երկրներում։</p>
           </div>
           
        </div>
  
        </div>
        
        
    )
   
}
export default About