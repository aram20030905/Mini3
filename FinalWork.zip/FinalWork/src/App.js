

import './App.css';
import Footer from './footer/Footer';
import Routese from './Route/Routese';

function App() {


  return (
    <div className="App">
  <Routese/>
  <Footer/>
    </div>
  );
}

export default App;
